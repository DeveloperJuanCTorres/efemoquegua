function setTransactionId(id){
    document.getElementById('transaction_id').value = id;
}
@component('accounting::components.tree_view_table', ['table_responsive' => true])
    @include('accounting::report.budget.partials.quarterly_view_table')
@endcomponent

<table class="table table-dark table-bordered table-striped table-hover" id="{{ $id }}">
    {{ $slot }}
</table>

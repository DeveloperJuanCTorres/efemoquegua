<?php

return [
    'connector_module' => 'Módulo conector',
    'connector' => 'Conector',
    'create_client' => 'Crear cliente',
    'client_secret' => 'Cliente secreto',
    'clients' => 'Clientes',
    'documentation' => 'Documentación',
];
